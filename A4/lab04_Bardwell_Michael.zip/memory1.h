/**********************************************************/
/*                       MEMORY1.H                        */
/*    Had to use memory1 because memory is already taken  */
/**********************************************************/

#ifndef memory1_h
#define memory1_h

extern void *my_malloc(int);
extern void my_free(void *);

#endif /* memory1_h */
